<h1 align="center">Fake Mailer</h1>
<p align="center">
    <a href="https://python.org">
    <img src="https://img.shields.io/badge/PHP-7.2.30-green.svg">
  </a>
  <a href="https://github.com/PushpenderIndia/technowhorse/blob/master/LICENSE">
    <img src="https://img.shields.io/badge/License-BSD%203-lightgrey.svg">
  </a>
  <a href="https://github.com/PushpenderIndia/technowhorse/releases">
    <img src="https://img.shields.io/badge/Release-1.0-blue.svg">
  </a>
    <a href="https://github.com/PushpenderIndia/technowhorse">
    <img src="https://img.shields.io/badge/Open%20Source-%E2%9D%A4-brightgreen.svg">
  </a>
</p>

Fake Mailer is a PHP Email Spoofer which is capable of sending spoofed or tampered emails to the target. No Need to Sign up, Send Email Anonymously, Demo Site is available for test!

## Disclaimer
<p align="center">
  :computer: This project was created only for good purposes and personal use.
</p>

THIS SOFTWARE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND. YOU MAY USE THIS SOFTWARE AT YOUR OWN RISK. THE USE IS COMPLETE RESPONSIBILITY OF THE END-USER. THE DEVELOPERS ASSUME NO LIABILITY AND ARE NOT RESPONSIBLE FOR ANY MISUSE OR DAMAGE CAUSED BY THIS PROGRAM.

## Features
- [x] Send Email From Any Browser
- [x] Easy to Setup
- [x] Simple & Good Looking UI

## Prerequisite
- [x] Any Web Hosting Service Which Supports PHP (**Premium Hosting is Recommend**)

## Installation & Usage
```bash
# Download OR Clone this repository
$ git clone https://github.com/PushpenderIndia/fakemailer.git

# Upload `index.html` & `mailer.php` To Your C-Panel (Hosting)

# Visit Your Site & You are ready to go!
```

## Note
* You can use Free Hosting as well such as `000webhost`, but there is high chance that email get marked as spam
* You can only send limited amount of emails if you upload this to free hosting. example- `000webhost` allows to send 25 emails per day

## Screenshot
![](/Screenshots/fakemailerV1.JPG)

